
# Health Provider web application

To start execute "npm install" to install dependenies
To run execute "npm start"
# WP_Project_Group6

CityHealthcare Provider
Group members:
Madhu Vijay Kumar, Shweta Singh, Shilong Zong, Yu Zhao
Github: https://github.com/ssingh59/WP_Project_Group6
The idea of healthcare provider application is to allow users to book online doctor’s appointment
through the website.
Core Features:
1. Book doctor’s appointment.
2. Search by doctor and hospitals.
3. Allow patients to make notes on what needs to be asked to a doctor prior to
appointment.
Main Page:
Specialities displayed on main page with icon for each eg. Primary care, Dentist etc.
User will be able to see the list of doctors under each speciality.
Search by doctor:
User will be able to see the listings of doctors.
Book Appointment:
User will be able to book appointment based on availability.
View Appointments:
Allow users to view their appointments on a calendar.
Cancel Appointment:
User will be able to cancel the appointment.
Search by Hospitals: User will be able to search hospital to find the doctor.
Extra Features:
1. Book lab tests: user will be able to book the lab test based on uploaded doctor prescription.
